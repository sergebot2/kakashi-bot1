#goatbot
╔══════════════════════════════════════╗
║          🖤 GOATBOT DARK EDITION 🖤          ║
╚══════════════════════════════════════╝

> ⚡ L’ombre parle, l’IA répond ⚡

![Dark AI](https://i.ibb.co/6RL70w8m/IMG-20250718-WA0003.jpg)

╔══════════════════════════════════════╗
║              📜 DESCRIPTION             ║
╚══════════════════════════════════════╝

GoatBot est un bot immersif pour Messenger.  
Tout est **dark & immersive**, du texte aux images,  
chaque commande vous plonge dans un univers mystérieux et stylisé.  

╔══════════════════════════════════════╗
║              🛠 COMMANDES               ║
╚══════════════════════════════════════╝

╭───────────────╮
│ `ai`           │ Pose une question à l’IA  
│                │ Texte stylisé + images  
├───────────────┤
│ `out`          │ Quitte le groupe avec message d’avertissement  
├───────────────┤
│ `adminkick`    │ Retire un membre admin  
├───────────────┤
│ `notification` │ Message global à tous les groupes  
├───────────────┤
│ `adduser`      │ Ajoute un membre dans le groupe  
╰───────────────╯

╔══════════════════════════════════════╗
║               🧙 AUTEUR                ║
╚══════════════════════════════════════╝

Octavio Wina — **le créateur dans l’ombre** 🖤  

> ⚔️ La puissance réside dans l’obscurité.  
> 🔮 Utilisez GoatBot avec sagesse et prudence.

╔══════════════════════════════════════╗
║            ⚠️ AVERTISSEMENT            ║
╚══════════════════════════════════════╝

Ne partagez jamais vos accès.  
GoatBot est conçu pour rester **immersion totale & sécurité maximale**.
